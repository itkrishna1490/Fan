package fan;

public class Fan {
	
	private String direction ="clockwise";
	private int speed=0;
	
	public String speedCord() {
		if(speed==3) {
			speed=0;
		}
		else {
			speed++;
		}
		return "Fan Spinning with "+speed+" speed"+" in "+direction;
	}
	public String directionCord() {
		if(direction.equals("clockwise")) {
			direction="anti-clockwise";
		}
		else {
			direction="clockwise";
		}
		return "Fan Spinning with "+speed+" speed"+" in "+direction;
	}
	
	public static void main(String[] args) {
		Fan fan = new Fan();
		System.out.println(fan.speedCord());
		System.out.println(fan.directionCord());
		System.out.println(fan.speedCord());
		System.out.println(fan.speedCord());
		System.out.println(fan.directionCord());
		System.out.println(fan.speedCord());
	}

}
