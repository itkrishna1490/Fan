module Fan {
}